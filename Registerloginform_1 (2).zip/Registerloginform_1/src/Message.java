import java.util.Random;

public class Message {
    private final String messageID;
    private final String recipient;
    private final String content;
    private static int messageCount = 0;

    public Message(String recipient, String content) {
        this.recipient = recipient;
        this.content = content;
        this.messageID = generateMessageID();
        messageCount++;
    }

    private String generateMessageID() {
        Random rand = new Random();
        return String.format("%010d", rand.nextInt(1000000000));
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+27") && recipient.length() <= 13;
    }

    public boolean checkMessageLength() {
        return content.length() <= 250;
    }

    public String createMessageHash() {
        String[] words = content.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + messageCount + ":" + firstWord + lastWord;
    }

    public String sendMessage(String action) {
        return switch (action) {
            case "Send" -> "Message successfully sent.";
            case "Disregard" -> "Press 0 to delete message.";
            case "Store" -> "Message successfully stored.";
            default -> "Invalid option.";
        };
    }

    public String printMessage() {
        return "Message ID: " + messageID + "\nHash: " + createMessageHash() + "\nRecipient: " + recipient + "\nMessage: " + content;
    }

    public static int returnTotalMessages() {
        return messageCount;
    }
}

