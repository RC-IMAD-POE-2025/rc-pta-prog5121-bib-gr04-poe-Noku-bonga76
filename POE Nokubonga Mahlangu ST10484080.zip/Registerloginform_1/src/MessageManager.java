import java.util.*;

public class MessageManager {

    static List<String> sentMessages = new ArrayList<>();
    static List<String> disregardedMessages = new ArrayList<>();
    static List<String> storedMessages = new ArrayList<>();
    static List<String> messageHashes = new ArrayList<>();
    static List<String> messageIDs = new ArrayList<>();

    static List<Message> allMessages = new ArrayList<>();

    public static void run() {
        loadTestData();  // Step 1

        // Step 2: Examples
        displaySendersAndRecipients();
        displayLongestMessage();
        searchByMessageID("0838884567");
        searchMessagesByRecipient("+27838884567");
        deleteByMessageHash("hash2");
        displayFullReport();
    }

    // Step 1: Load Test Data
    public static void loadTestData() {
        addMessage("+27834557896", "Did you get the cake?", "Sent");
        addMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        addMessage("+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        addMessage("0838884567", "It is dinner time !", "Sent");
        addMessage("+27838884567", "Ok, I am leaving without you.", "Stored");
    }

    public static void addMessage(String recipient, String message, String flag) {
        String id = recipient;
        String hash = "hash" + (messageHashes.size() + 1);
        Message msg = new Message(id, recipient, message, flag, hash);

        allMessages.add(msg);
        messageIDs.add(id);
        messageHashes.add(hash);

        switch (flag) {
            case "Sent" -> sentMessages.add(message);
            case "Stored" -> storedMessages.add(message);
            case "Disregard" -> disregardedMessages.add(message);
        }
    }

    public static void displaySendersAndRecipients() {
        System.out.println("Senders and Recipients:");
        for (Message msg : allMessages) {
            if (msg.flag.equals("Sent")) {
                System.out.println("From: " + msg.sender + " To: " + msg.recipient);
            }
        }
    }

    public static void displayLongestMessage() {
        String longest = "";
        for (Message msg : allMessages) {
            if (msg.flag.equals("Sent") && msg.message.length() > longest.length()) {
                longest = msg.message;
            }
        }
        System.out.println("Longest Message: " + longest);
    }

    public static void searchByMessageID(String id) {
        for (Message msg : allMessages) {
            if (msg.sender.equals(id)) {
                System.out.println("Message for ID " + id + ": " + msg.message);
                return;
            }
        }
        System.out.println("Message ID not found.");
    }

    public static void searchMessagesByRecipient(String recipient) {
        System.out.println("Messages sent to: " + recipient);
        for (Message msg : allMessages) {
            if (msg.recipient.equals(recipient) && (msg.flag.equals("Sent") || msg.flag.equals("Stored"))) {
                System.out.println(msg.message);
            }
        }
    }

    public static void deleteByMessageHash(String hash) {
        Iterator<Message> iterator = allMessages.iterator();
        while (iterator.hasNext()) {
            Message msg = iterator.next();
            if (msg.hash.equals(hash)) {
                iterator.remove();
                System.out.println("Message \"" + msg.message + "\" successfully deleted.");
                return;
            }
        }
        System.out.println("Message hash not found.");
    }

    public static void displayFullReport() {
        System.out.println("Sent Message Report:");
        for (Message msg : allMessages) {
            if (msg.flag.equals("Sent")) {
                System.out.println("Hash: " + msg.hash + " | Recipient: " + msg.recipient + " | Message: " + msg.message);
            }
        }
    }

    // Define Message class
    static class Message {
        String sender, recipient, message, flag, hash;

        public Message(String sender, String recipient, String message, String flag, String hash) {
            this.sender = sender;
            this.recipient = recipient;
            this.message = message;
            this.flag = flag;
            this.hash = hash;
        }
    }
}
