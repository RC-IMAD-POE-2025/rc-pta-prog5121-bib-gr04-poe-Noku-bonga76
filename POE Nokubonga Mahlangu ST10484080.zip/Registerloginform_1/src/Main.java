public class Main {
    public static void main(String[] args) {
        MessageManager.run();  // This will be your main logic class
    }
}

